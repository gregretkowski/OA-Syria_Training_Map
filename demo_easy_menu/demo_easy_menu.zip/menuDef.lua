env.info("Defining easy menu...")

easyMenu = string.format([[
Support Aircraft/Shell 1-1/Altitude/Increase =200
Support Aircraft/Shell 1-1/Altitude/Decrease =201
Support Aircraft/Shell 1-1/Speed/Increase    =210
Support Aircraft/Shell 1-1/Speed/Decrease    =211
Support Aircraft/Shell 1-1/Reset TACAN       =220

Support Aircraft/Shell 2-1/Altitude/Increase =250
Support Aircraft/Shell 2-1/Altitude/Decrease =251
Support Aircraft/Shell 2-1/Speed/Increase    =260
Support Aircraft/Shell 2-1/Speed/Decrease    =261
Support Aircraft/Shell 2-1/Reset TACAN       =270

CAS/Range 1/Air Defenses/Enable              =500
CAS/Range 1/Air Defenses/Disable             =501
CAS/Range 1/Reset All Units/Confirm? YES     =510

CAS/Range 2/Air Defenses/Enable              =600
CAS/Range 2/Air Defenses/Disable             =601
CAS/Range 2/Reset All Units/Confirm? YES     =610

CAS/Range 3/Air Defenses/Enable              =700
CAS/Range 3/Air Defenses/Disable             =701
CAS/Range 3/Reset All Units/Confirm? YES     =710

Reset All/Confirm? YES                       =999
]])